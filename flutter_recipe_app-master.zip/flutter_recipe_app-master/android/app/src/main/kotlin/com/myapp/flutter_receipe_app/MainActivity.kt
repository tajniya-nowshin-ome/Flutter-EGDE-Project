package com.myapp.flutter_receipe_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
