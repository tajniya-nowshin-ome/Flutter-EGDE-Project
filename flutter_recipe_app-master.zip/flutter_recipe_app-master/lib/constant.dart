

//recipe names
String recipe1Name="Falafel Burgers";
String recipe2Name="Chicken Biryani";
String recipe3Name="Chocklet Cake";
String recipe4Name="Mexican Pizza";


//recipe images
String image1="burger.jpg";
String image2="biriyani.jpg";
String image3="cake.jpg";
String image4="pizza.jpg";


//recipe descriptions
String description1="Pat the chickpeas dry with kitchen paper. Tip into a food processor along with the onion, garlic, parsley, spices, flour and a little salt. Blend until fairly smooth, then shape into four patties with your hands. Heat the oil in a non-stick frying pan, add the burgers, then quickly fry for 3 mins on each side until lightly golden. Serve with toasted pittas, tomato salsa and a green salad.";
String description2="Soak the rice in warm water, then wash in cold until the water runs clear. Heat butter in a saucepan and cook the onions with the bay leaf and other whole spices for 10 mins. Sprinkle in the turmeric, then add chicken and curry paste and cook until aromatic. Stir the rice into the pan with the raisins, then pour over the stock. Place a tight-fitting lid on the pan and bring to a hard boil, then lower the heat to a minimum and cook the rice for another 5 mins. Turn off the heat and leave for 10 mins. Stir well, mixing through half the coriander. To serve, scatter over the rest of the coriander and the almonds.";
String description3="Heat oven to 180C/fan 160C/gas . Grease and line a 20cm cake tin. Place the butter, caster sugar, brown sugar, chocolate and golden syrup in the pan and melt gently on a low heat until it is smooth and lump-free. Remove the pan from the heat. Break the eggs into the bowl and whisk with the fork until light and frothy. Add the eggs, vanilla extract or essence, flour, baking powder and cocoa powder to the chocolate mixture and mix thoroughly. Put the mixture into the greased and lined cake tin and place on the middle shelf of the oven. Bake for 25-30 mins. Remove and allow to cool for 20-30 mins before cutting into wedges and serving. Serve with cream or ice cream and plenty of fresh fruit.";
String description4="To prepare the pizza, preheat the oven to 200C/Gas 6/fan 180C. Put the pizza base on a baking sheet and spread with the sauce.To cook the spinach, put it in a microwavable bowl, cover with cling film and pierce it a couple of times. Put in the microwave on High (850W) for 2 minutes until wilted (or cook in a covered pan for 2-3 minutes). Drain and spread the spinach over the pizza base, then get the mushrooms out of the jar with a fork and scatter them over the top. Season and sprinkle with half the parmesan. Bake for 10 minutes.Make four dips in the spinach with the back of a spoon, and crack an egg into each. Sprinkle with the remaining cheese and bake for a further 6- 8 minutes, until the eggs are just set.";





